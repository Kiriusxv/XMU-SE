from flask import Flask, jsonify, render_template, request
import mysql.connector
import requests
import json

app = Flask(__name__)

# 数据库配置
db_config = {
    'user': 'root',
    'password': 'renyu20031205.',
    'host': 'localhost',
    'database': 'IoTFinal',
    'raise_on_warnings': True
}

# 钉钉 Webhook URL
DINGTALK_WEBHOOK = "https://oapi.dingtalk.com/robot/send?access_token=1dfbb73ec199d9e975d0926ef739a2f9d68d66707feb20dbba543227e19c67ca"

# 文心一言 API 配置
API_KEY = "qAWTwT2cdrK0ITarm0B6iGgO"
SECRET_KEY = "EFPjdmlypBcBs0KY1xGXBoN7vEuT0jad"
WENXIN_YIYAN_API_URL = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/yi_34b_chat?access_token="

def get_access_token():
    url = f"https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={API_KEY}&client_secret={SECRET_KEY}"
    response = requests.post(url, headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
    return response.json().get("access_token")

def get_soil_data():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("SELECT depth_cm, temperature, humidity, timestamp FROM soil_data ORDER BY timestamp DESC LIMIT 3")
    data = cursor.fetchall()
    conn.close()
    return data

def get_weather_data():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("SELECT temperature, humidity, wind_direction, wind_speed, rainfall, evaporation, pressure, timestamp FROM weather_data ORDER BY timestamp DESC LIMIT 1")
    data = cursor.fetchall()
    conn.close()
    return data

def get_alerts():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("SELECT sensor_type, alert_message, timestamp FROM alerts ORDER BY timestamp DESC")
    data = cursor.fetchall()
    conn.close()
    return data

def get_history_data():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("SELECT depth_cm, temperature, humidity, timestamp FROM soil_data ORDER BY timestamp DESC LIMIT 100")
    soil_data = cursor.fetchall()
    cursor.execute("SELECT temperature, humidity, wind_direction, wind_speed, rainfall, evaporation, pressure, timestamp FROM weather_data ORDER BY timestamp DESC LIMIT 100")
    weather_data = cursor.fetchall()
    conn.close()
    return soil_data, weather_data

def send_dingtalk_message(message, sensor_type, timestamp):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM alerts WHERE sensor_type = %s AND timestamp = %s", (sensor_type, timestamp))
    if cursor.fetchone() is None:
        headers = {'Content-Type': 'application/json;charset=utf-8'}
        data = {"msgtype": "text", "text": {"content": message}}
        response = requests.post(DINGTALK_WEBHOOK, headers=headers, data=json.dumps(data))
        cursor.execute("INSERT INTO alerts (sensor_type, alert_message, timestamp) VALUES (%s, %s, %s)", (sensor_type, message, timestamp))
        conn.commit()
    cursor.close()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/data')
def data():
    soil_data = get_soil_data()
    weather_data = get_weather_data()
    alerts = get_alerts()
    
    result = {'soil_data': [], 'weather_data': [], 'alerts': [], 'current_alerts': []}
    
    for depth_cm, temp, humidity, timestamp in soil_data:
        formatted_timestamp = timestamp.strftime('%Y-%m-%d %H:%M:%S')
        result['soil_data'].append({'depth_cm': depth_cm, 'temperature': temp, 'humidity': humidity, 'timestamp': formatted_timestamp})
        if temp > 35 or temp < 10:
            alert_message = f"Alert: Soil temperature at {formatted_timestamp} is {temp}°C"
            send_dingtalk_message(alert_message, 'soil', timestamp)
            result['current_alerts'].append({'sensor_type': 'soil', 'alert_message': alert_message, 'timestamp': formatted_timestamp})
        if humidity > 80 or humidity < 20:
            alert_message = f"Alert: Soil humidity at {formatted_timestamp} is {humidity}%"
            send_dingtalk_message(alert_message, 'soil', timestamp)
            result['current_alerts'].append({'sensor_type': 'soil', 'alert_message': alert_message, 'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S')})
    
    for temp, humidity, wind_direction, wind_speed, rainfall, evaporation, pressure, timestamp in weather_data:
        formatted_timestamp = timestamp.strftime('%Y-%m-%d %H:%M:%S')
        result['weather_data'].append({
            'temperature': temp, 'humidity': humidity, 'wind_direction': wind_direction, 
            'wind_speed': wind_speed, 'rainfall': rainfall, 'evaporation': evaporation, 
            'pressure': pressure, 'timestamp': formatted_timestamp
        })
        if temp > 35 or temp < 10:
            alert_message = f"Alert: Weather temperature at {formatted_timestamp} is {temp}°C"
            send_dingtalk_message(alert_message, 'weather', timestamp)
            result['current_alerts'].append({'sensor_type': 'weather', 'alert_message': alert_message, 'timestamp': formatted_timestamp})
        if humidity > 80 or humidity < 20:
            alert_message = f"Alert: Weather humidity at {formatted_timestamp} is {humidity}%"
            send_dingtalk_message(alert_message, 'weather', timestamp)
            result['current_alerts'].append({'sensor_type': 'weather', 'alert_message': alert_message, 'timestamp': formatted_timestamp})
        if pressure > 1025 or pressure < 990:
            alert_message = f"Alert: Weather pressure at {formatted_timestamp} is {pressure} hPa"
            send_dingtalk_message(alert_message, 'weather', timestamp)
            result['current_alerts'].append({'sensor_type': 'weather', 'alert_message': alert_message, 'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S')})
    
    for sensor_type, alert_message, timestamp in alerts:
        result['alerts'].append({'sensor_type': sensor_type, 'alert_message': alert_message, 'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S')})
    
    return jsonify(result)

@app.route('/alerts')
def alert_log():
    return render_template('alertlog.html')

@app.route('/historydata')
def history_data():
    soil_data, weather_data = get_history_data()
    
    result = {'soil_data': [], 'weather_data': []}
    
    for depth_cm, temp, humidity, timestamp in soil_data:
        result['soil_data'].append({
            'depth_cm': depth_cm,
            'temperature': temp,
            'humidity': humidity,
            'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    for temp, humidity, wind_direction, wind_speed, rainfall, evaporation, pressure, timestamp in weather_data:
        result['weather_data'].append({
            'temperature': temp,
            'humidity': humidity,
            'wind_direction': wind_direction,
            'wind_speed': wind_speed,
            'rainfall': rainfall,
            'evaporation': evaporation,
            'pressure': pressure,
            'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify(result)

@app.route('/teasuggestion', methods=['GET'])
def tea_suggestion():
    # 获取最新的土壤和天气数据
    soil_data = get_soil_data()
    weather_data = get_weather_data()

    if not soil_data or not weather_data:
        return jsonify({'error': 'No sensor data available'}), 404

    latest_soil_data = soil_data[0]
    latest_weather_data = weather_data[0]

    # 构建请求数据
    request_data = {
        'messages': [
            {
                'role': 'user',
                'content': f"根据以下传感器数据，提供茶叶种植建议：土壤深度：{latest_soil_data[0]}cm，土壤温度：{latest_soil_data[1]}°C，土壤湿度：{latest_soil_data[2]}%，气温：{latest_weather_data[0]}°C，空气湿度：{latest_weather_data[1]}%，降雨量：{latest_weather_data[4]}mm，蒸发量：{latest_weather_data[5]}mm，气压：{latest_weather_data[6]}hPa。参考以下格式：根据您提供的传感器数据，以下是为茶叶种植提供的建议： 1. 土壤深度：10cm - 对于茶叶种植，土壤深度通常不是问题，因为茶叶根系并不需要很深的土壤。但是，如果土壤表层较浅，可以考虑适当添加覆盖物以保持土壤湿润和温度稳定。 2. 土壤温度：24.96°C - 茶叶生长的最佳土壤温度通常在18°C到25°C之间。目前土壤温度适宜茶叶生长。 3. 土壤湿度：48.11% - 茶叶生长所需的土壤湿度通常在40%到60%之间。目前的土壤湿度水平适宜茶叶生长。 4. 气温：15.55°C - 茶叶生长的最佳气温通常在15°C到25°C之间。目前的气温适宜茶叶生长。 5. 空气湿度：77.66% - 茶叶生长喜欢较高的空气湿度。目前的空气湿度水平适宜茶叶生长。 6. 降雨量：6.02mm - 茶叶生长需要适量的降雨。根据具体情况（如土壤保水性和植物水分需求），可能需要额外灌溉。 7. 蒸发量：0.06mm - 蒸发量低意味着土壤水分损失较少，有利于保持土壤湿度。 8. 气压：1044.79hPa - 气压对茶叶生长的影响较小，但低气压可能意味着天气变化，需要注意防范可能的干旱或暴雨。 综合以上数据，目前的条件总体上适宜茶叶生长。建议继续监测土壤湿度，并根据实际情况进行灌溉，以保持适宜的土壤水分条件。同时，注意天气变化，做好相应的防护措施。请你注意：回复总字数不能超过五十字。"
            }
        ],
        'stream': True
    }

    access_token = get_access_token()
    if not access_token:
        return jsonify({'error': 'Failed to get access token'}), 500

    headers = {'Content-Type': 'application/json'}
    response = requests.post(WENXIN_YIYAN_API_URL + access_token, headers=headers, data=json.dumps(request_data), stream=True)

    if response.status_code == 200:
        suggestions = [line.decode("UTF-8") for line in response.iter_lines() if line]
        # 提取和组合 data 中的 result 字段
        suggestion_str = ""
        for suggestion in suggestions:
            if suggestion.startswith("data:"):
                data = json.loads(suggestion[len("data: "):])
                suggestion_str += data.get('result', '')
        return suggestion_str
    else:
        return jsonify({'error': 'Failed to get suggestion from Wenxin Yiyan'}), response.status_code

if __name__ == '__main__':
    app.run(debug=True)

