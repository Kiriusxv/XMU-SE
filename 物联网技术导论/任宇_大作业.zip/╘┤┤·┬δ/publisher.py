import random
import json
import time
from datetime import datetime
from paho.mqtt import client as mqtt_client

# MQTT服务器的配置参数
broker = '192.168.232.167'  # MQTT代理服务器的IP地址
port = 1883  # MQTT使用的端口号，默认为1883
topics = {
    "sensor/soil": "sensor/soil",
    "sensor/weather": "sensor/weather"
}  # MQTT主题，用于发布消息
client_id = f'python-mqtt-{random.randint(0, 1000)}'  # 客户端ID，随机生成以避免冲突


def generate_soil_sensor_data():
    current_hour = datetime.now().hour
    soil_data = []
    
    if 6 <= current_hour < 18:  # 白天
        temperature_range = (15.0, 35.0)
        humidity_range = (20.0, 60.0)
    else:  # 晚上
        temperature_range = (10.0, 25.0)
        humidity_range = (40.0, 80.0)
    
    depths = [10, 20, 30]
    for depth in depths:
        data = {
            "depth_cm": depth,
            "temperature": round(random.uniform(*temperature_range), 2),  # 模拟土壤温度数据，单位摄氏度
            "humidity": round(random.uniform(*humidity_range), 2)  # 模拟土壤湿度数据，百分比
        }
        soil_data.append(data)
    
    return soil_data

def generate_weather_sensor_data():
    current_hour = datetime.now().hour
    if 6 <= current_hour < 18:  # 白天
        temperature = round(random.uniform(20.0, 35.0), 2)
        humidity = round(random.uniform(30.0, 60.0), 2)
        wind_speed = round(random.uniform(1.0, 15.0), 2)
        evaporation = round(random.uniform(0.5, 5.0), 2)
    else:  # 晚上
        temperature = round(random.uniform(15.0, 25.0), 2)
        humidity = round(random.uniform(50.0, 90.0), 2)
        wind_speed = round(random.uniform(0.0, 10.0), 2)
        evaporation = round(random.uniform(0.0, 1.0), 2)
    
    data = {
        "temperature": temperature,  # 模拟气温数据，单位摄氏度
        "humidity": humidity,  # 模拟气象湿度数据，百分比
        "wind_direction": random.choice(["东风", "西风", "南风", "北风","东北风","东南风","西北风","西南风"]),  # 模拟风向数据
        "wind_speed": wind_speed,  # 模拟风速数据，单位m/s
        "rainfall": round(random.uniform(0.0, 10.0), 2),  # 模拟降雨量数据，单位mm
        "evaporation": evaporation,  # 模拟蒸发量数据，单位mm
        "pressure": round(random.uniform(950.0, 1050.0), 2)  # 模拟气压数据，单位hPa
    }
    return data

def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print(f"Failed to connect, return code {rc}\n")

    client = mqtt_client.Client(mqtt_client.CallbackAPIVersion.VERSION1,client_id)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client

def publish(client):
    try:
        while True:
            soil_data = generate_soil_sensor_data()  # 生成模拟的土壤传感器数据
            weather_data = generate_weather_sensor_data()  # 生成模拟的气象传感器数据
            
            soil_message = json.dumps(soil_data)
            weather_message = json.dumps(weather_data)

            result1 = client.publish(topics["sensor/soil"], soil_message)
            result2 = client.publish(topics["sensor/weather"], weather_message)

            status1 = result1.rc
            status2 = result2.rc

            if status1 == 0:
                print(f"Send `{soil_message}` to topic `{topics['sensor/soil']}`")
            else:
                print(f"Failed to send message to topic {topics['sensor/soil']}`")

            if status2 == 0:
                print(f"Send `{weather_message}` to topic `{topics['sensor/weather']}`")
            else:
                print(f"Failed to send message to topic {topics['sensor/weather']}`")
            
            time.sleep(10)  # 每10秒发送一次数据
    except KeyboardInterrupt:
        print("Publishing stopped by user")

def run():
    client = connect_mqtt()
    client.loop_start()
    try:
        publish(client)
    finally:
        client.loop_stop()

if __name__ == '__main__':
    run()
