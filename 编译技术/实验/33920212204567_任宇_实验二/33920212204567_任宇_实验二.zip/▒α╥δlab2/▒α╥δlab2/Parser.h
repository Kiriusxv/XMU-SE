#pragma once
#include "Lexer.h"

class TypeC {
public:
    std::string code;
    int True;
    int False;

    TypeC() : code(""), True(0), False(0) {}
};

class TypeE {
public:
    std::string code;
    std::string place;

    TypeE() : code(""), place("") {}
};

class TypeF {
public:
    std::string code;
    std::string place;

    TypeF() : code(""), place("") {}
};

class TypeS {
public:
    std::string code;
    int next;
    int begin;
    bool isS1;
    bool end;

    TypeS() : code(""), next(0), begin(0), isS1(false), end(false) {}
};

class TypeSd {
public:
    std::string code;
    int begin;
    int next;

    TypeSd() : code(""), begin(0), next(0) {}
};

class TypeStart {
public:
    std::string code;

    TypeStart() : code("") {}
};

class TypeT {
public:
    std::string code;
    std::string place;

    TypeT() : code(""), place("") {}
};

class Parser {
private:
    std::vector<Word> words;
    int start = 0;
    int end = 0;
    Word currentWord;
    int label = 0;
    int val = 0;
public:
    Parser() : label(0) {}
    bool getNext();
    std::string newTemp();
    void setWords(const std::vector<Word>& wordList);
    bool Start(TypeStart& typeStart);
    bool analyseS(TypeS& typeS);
    int newLabel();
    bool analyseSDouble(TypeSd& typeSd);
    bool analyseC(TypeC& typeC);
    bool analyseE(TypeE& typeE);
    bool analyseT(TypeT& typeT);
    bool analyseF(TypeF& typeF);
};