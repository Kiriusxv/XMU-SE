#include "Lexer.h"

void Word::setContent(const std::string& c) {
    content = c;
}

void Word::setType(const std::string& t) {
    type = t;
}

std::string Word::getContent() const {
    return content;
}

std::string Word::getType() const {
    return type;
}


void WordScan::scan(const std::string& s, std::vector<Word>& result) {
    const char* c = s.c_str();
    int n = 0;
    int len = s.length();
    if (isKeyWords(s)) {
        Word temp;
        temp.content = "_";
        temp.type = s;
        result.push_back(temp);
        return;
    }
    if (len == 1) {
        if (c[0] >= '0' && c[0] <= '9') {
            Word temp;
            temp.content = s;
            temp.type = "INT10";
            result.push_back(temp);
        }
        else if ((c[0] >= 'a' && c[0] <= 'z') || (c[0] >= 'A' && c[0] <= 'Z')) {
            Word temp;
            temp.content = s;
            temp.type = "IDN";
            result.push_back(temp);
        }
        else {
            isOtherString(s, 0, result);
        }
        return;
    }
    while (n < len) {
        if (c[n] >= '1' && c[n] <= '9') {
            n = decimalNumbers(s, result, n);
        }
        else if (c[n] == '0') {
            if (n + 1 < len && (c[n + 1] == 'o' || c[n + 1] == 'O')) {
                n = octalNumbers(s, result, n + 2);
            }
            else if (n + 1 < len && (c[n + 1] == 'x' || c[n + 1] == 'X')) {
                n = hexadecimalNumbers(s, result, n + 2);
            }
            else if (n + 1 < len && c[n + 1] == '.') {
                int tempLen = 0;
                double num2 = 0.0;
                num2 += digit(s, n + 2, 10, &tempLen);
                Word x;
                x.content = std::to_string(num2);
                x.type = "INT10";
                result.push_back(x);
                n += tempLen + 2;
            }
            else if (n + 1 < len && c[n + 1] >= '0' && c[n + 1] <= '9') {
                n = decimalNumbers(s, result, n + 1);
            }
            else {
                std::cout << "scan c[n]=0 error\n";
                break;
            }
        }
        else if ((c[n] >= 'a' && c[n] <= 'z') || (c[n] >= 'A' && c[n] <= 'Z')) {
            n = idn(s, n, result);
        }
        else {
            isOtherString(s, n, result);
            n++;
        }
    }
}
//����ʮ������
int WordScan::decimalNumbers(const std::string& s, std::vector<Word>& result, int now) {
    const char* c = s.c_str();
    int tempLen = 0;
    int num = 0;
    double num2 = 0.0;
    int l = 0;
    int flag = 0;
    for (int i = now; i < s.length(); i++) {
        if (c[i] >= '0' && c[i] <= '9') {
            num = (c[i] - '0') + num * 10;
            num2 = num;
            l++;
        }
        else if (c[i] == '.') {
            num2 += digit(s, i + 1, 10, &tempLen);
            flag = 1;
            l++;
            i += tempLen;
            l += tempLen;
        }
        else {
            Word temp;
            if (flag == 1) {
                temp.content = std::to_string(num2);
                temp.type = "REAL10";
            }
            else {
                temp.content = std::to_string(num);
                temp.type = "INT10";
            }
            result.push_back(temp);
            return now + l;
        }
    }
    Word r;
    if (flag == 1) {
        r.content = std::to_string(num2);
        r.type = "REAL10";
    }
    else {
        r.content = std::to_string(num);
        r.type = "INT10";
    }
    result.push_back(r);
    return now + l;
}
//�����˽�����
int WordScan::octalNumbers(const std::string& s, std::vector<Word>& result, int now) {
    const char* c = s.c_str();
    int num = 0;
    int tempLen = 0;
    double num2 = 0.0;
    int l = 0;
    int flag = 0;
    for (int i = now; i < s.length(); i++) {
        if (c[i] >= '0' && c[i] <= '7') {
            num = (c[i] - '0') + num * 8;
            num2 = num;
            l++;
        }
        else if (c[i] == '.') {
            num2 += digit(s, i + 1, 8, &tempLen);
            flag = 1;
            l++;
            i += tempLen;
            l += tempLen;
        }
        else {
            Word temp;
            temp.type = "INT8";
            if (flag == 1) {
                temp.content = std::to_string(num2);
            }
            else {
                temp.content = std::to_string(num);
            }
            result.push_back(temp);
            return now + l;
        }
    }
    Word r;
    if (flag == 1) {
        r.content = std::to_string(num2);
        r.type = "INT8";
    }
    else {
        r.content = std::to_string(num);
        r.type = "INT8";
    }
    result.push_back(r);
    return now + l;
}
//����ʮ��������
int WordScan::hexadecimalNumbers(const std::string& s, std::vector<Word>& result, int now) {
    const char* c = s.c_str();
    int tempLen = 0;
    int num = 0;
    double num2 = 0.0;
    int l = 0;
    int flag = 0;
    for (int i = now; i < s.length(); i++) {
        if (c[i] >= '0' && c[i] <= '9') {
            num = (c[i] - '0') + num * 16;
            num2 = num;
            l++;
        }
        else if ((c[i] >= 'a' && c[i] <= 'z') || (c[i] >= 'A' && c[i] <= 'Z')) {
            num = (c[i] - 'a' + 10) + num * 16;
            num2 = num;
            l++;
        }
        else if (c[i] == '.') {
            num2 += digit(s, i + 1, 16, &tempLen);
            flag = 1;
            l++;
            i += tempLen;
            l += tempLen;
        }
        else {
            Word temp;
            temp.type = "INT16";
            if (flag == 1) {
                temp.content = std::to_string(num2);
            }
            else {
                temp.content = std::to_string(num);
            }
            result.push_back(temp);
            return now + l;
        }
    }
    Word r;
    if (flag == 1) {
        r.content = std::to_string(num2);
        r.type = "INT16";
    }
    else {
        r.content = std::to_string(num);
        r.type = "INT16";
    }
    result.push_back(r);
    return now + l;
}
//������ʶ��
int WordScan::idn(const std::string& s, int now, std::vector<Word>& result) {
    const char* c = s.c_str();
    std::string sb;
    int l = 0;
    for (int i = now; i < s.length(); i++) {
        if ((c[i] >= 'a' && c[i] <= 'z') || (c[i] >= 'A' && c[i] <= 'Z')) {
            sb.push_back(c[i]);
            l++;
        }
        else if (c[i] == '_' || c[i] == '.') {
            sb.push_back(c[i]);
            l++;
        }
        else if (c[i] >= '0' && c[i] <= '9') {
            sb.push_back(c[i]);
            l++;
        }
        else {
            Word temp;
            temp.content = sb;
            temp.type = "IDN";
            result.push_back(temp);
            return now + l;
        }
    }
    Word r;
    r.content = sb;
    r.type = "IDN";
    result.push_back(r);
    return now + l;
}
//���ս��ƴ���С�����
double WordScan::digit(const std::string& s, int next, int type, int* tempLen) {
    const char* c = s.c_str();
    double result = 0.0;
    double base = type;
    *tempLen = 0;
    for (int i = next; i < s.length(); i++) {
        if (c[i] >= '0' && c[i] <= '9') {
            result += ((double)(c[i] - '0')) / base;
            base *= type;
            (*tempLen)++;
        }
        else if ((c[i] >= 'a' && c[i] <= 'f') || (c[i] >= 'A' && c[i] <= 'F')) {
            int num = (c[i] > '9') ? (c[i] - 'a' + 10) : (c[i] - 'A' + 10);
            result += ((double)num) / base;
            base *= type;
            (*tempLen)++;
        }
        else break;
    }
    return result;
}
//�Ƿ�Ϊunknow
void WordScan::isOtherString(const std::string& s, int now, std::vector<Word>& result) {
    char c = s[now];
    bool found = false;
    for (char op : operators) {
        if (c == op) {
            Word temp;
            temp.content = "_";
            temp.type = std::string(1, c);
            result.push_back(temp);
            found = true;
            break;
        }
    }
    if (!found) {
        Word temp;
        temp.content = std::string(1, c);
        temp.type = "unknown";
        result.push_back(temp);
    }
}
//�Ƿ�Ϊ�ؼ���
bool WordScan::isKeyWords(const std::string& s) {
    for (const std::string& kw : keyWords) {
        if (s == kw) return true;
    }
    return false;
}