#include "Parser.h"

int main() {
    std::ifstream file("data.txt");
    std::stringstream sb;
    if (file.is_open()) {
        std::string s;
        while (getline(file, s)) {
            std::vector<std::string> words;
            std::istringstream iss(s);
            std::string word;
            while (iss >> word) {
                words.push_back(word);
            }
            std::vector<Word> wordList;
            WordScan wordScan;
            for (const std::string& word : words) {
                wordScan.scan(word, wordList);
            }
            Parser parser;
            parser.setWords(wordList);
            TypeStart typeStart;
            bool result = parser.Start(typeStart);
            if (result) {
                std::cout << typeStart.code << std::endl;
            }
            else {
                std::cout << "Syntax analysis failed" << std::endl;
            }
        }
        file.close();
    }
    else {
        std::cerr << "Unable to open file" << std::endl;
    }
    return 0;
}